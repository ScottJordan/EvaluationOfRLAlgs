for d in */ ; do
	cd $d
	rm allres*.csv
	cat actorcritic_*.csv >> allres_ac-normal.csv
	rm actorcritic_*.csv
	cat actorcritic-scaled*.csv >> allres_ac-scaled.csv
	cat actorcritic-parl2*.csv >> allres_ac-parl2.csv
	rm actorcritic-*.csv
	cat sarsalambda_*.csv >> allres_sarsa-normal.csv
	cat sarsalambda-scaled_*.csv >> allres_sarsa-scaled.csv	
	cat sarsa-parl2*.csv >> allres_sarsa-parl2.csv
	rm sarsa*.csv
	cat qlambda_*.csv >> allres_qlambda-normal.csv	
	cat qlambda-scaled_*.csv >> allres_qlambda-scaled.csv	
	cat q-parl2*.csv >> allres_q-parl2.csv
	rm q*.csv
	cat nactd_*.csv >> allres_nactd.csv
	rm nact*.csv
	cat ppo_*.csv >> allres_ppo.csv	
	rm ppo*.csv
	cd ..
done
